import { db } from "./db";
import { productTypes, materials, units, products } from "@shared/schema";

async function seed() {
  console.log("🌱 Starting database seed...");

  try {
    // Seed Product Types
    const types = await db
      .insert(productTypes)
      .values([
        { name: "Banner", description: "Banner printing products" },
        { name: "Sticker", description: "Sticker and label products" },
        { name: "Brosur", description: "Brochure and flyer products" },
        { name: "Kartu Nama", description: "Business card products" },
        { name: "Undangan", description: "Invitation card products" },
      ])
      .returning();
    console.log(`✅ Created ${types.length} product types`);

    // Seed Materials
    const mats = await db
      .insert(materials)
      .values([
        { name: "Vinyl", description: "Vinyl material" },
        { name: "Flexi Korea", description: "Flexi Korea material" },
        { name: "Stiker Vinyl", description: "Vinyl sticker material" },
        { name: "Art Paper", description: "Art paper material" },
        { name: "HVS", description: "HVS paper" },
      ])
      .returning();
    console.log(`✅ Created ${mats.length} materials`);

    // Seed Units
    const unitsData = await db
      .insert(units)
      .values([
        { name: "meter", abbreviation: "m" },
        { name: "lembar", abbreviation: "lbr" },
        { name: "pcs", abbreviation: "pcs" },
        { name: "rim", abbreviation: "rim" },
        { name: "pak", abbreviation: "pak" },
      ])
      .returning();
    console.log(`✅ Created ${unitsData.length} units`);

    // Seed Products
    const prods = await db
      .insert(products)
      .values([
        {
          name: "Banner 3x1 meter",
          typeId: types[0].id,
          materialId: mats[0].id,
          unitId: unitsData[0].id,
          price: "150000",
        },
        {
          name: "Sticker A4",
          typeId: types[1].id,
          materialId: mats[2].id,
          unitId: unitsData[1].id,
          price: "5000",
        },
        {
          name: "Brosur A5",
          typeId: types[2].id,
          materialId: mats[3].id,
          unitId: unitsData[1].id,
          price: "3000",
        },
      ])
      .returning();
    console.log(`✅ Created ${prods.length} products`);

    console.log("✅ Database seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

seed()
  .then(() => process.exit(0))
  .catch(() => process.exit(1));
