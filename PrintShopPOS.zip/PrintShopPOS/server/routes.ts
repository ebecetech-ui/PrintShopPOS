import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { requireRole } from "./middleware/authorize";
import {
  insertProductTypeSchema,
  insertMaterialSchema,
  insertUnitSchema,
  insertProductSchema,
  insertCustomerSchema,
  insertOrderSchema,
  insertOrderItemSchema,
  insertPaymentSchema,
  insertExpenseSchema,
  insertAppSettingSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Product Types Routes (Admin, Owner only)
  app.get("/api/product-types", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const types = await storage.getAllProductTypes();
      res.json(types);
    } catch (error) {
      console.error("Error fetching product types:", error);
      res.status(500).json({ message: "Failed to fetch product types" });
    }
  });

  app.post("/api/product-types", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const data = insertProductTypeSchema.parse(req.body);
      const type = await storage.createProductType(data);
      res.status(201).json(type);
    } catch (error: any) {
      console.error("Error creating product type:", error);
      res.status(400).json({ message: error.message || "Failed to create product type" });
    }
  });

  app.patch("/api/product-types/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const type = await storage.updateProductType(req.params.id, req.body);
      if (!type) {
        return res.status(404).json({ message: "Product type not found" });
      }
      res.json(type);
    } catch (error) {
      console.error("Error updating product type:", error);
      res.status(500).json({ message: "Failed to update product type" });
    }
  });

  app.delete("/api/product-types/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const success = await storage.deleteProductType(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product type not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product type:", error);
      res.status(500).json({ message: "Failed to delete product type" });
    }
  });

  // Materials Routes (Admin, Owner only)
  app.get("/api/materials", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const materials = await storage.getAllMaterials();
      res.json(materials);
    } catch (error) {
      console.error("Error fetching materials:", error);
      res.status(500).json({ message: "Failed to fetch materials" });
    }
  });

  app.post("/api/materials", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const data = insertMaterialSchema.parse(req.body);
      const material = await storage.createMaterial(data);
      res.status(201).json(material);
    } catch (error: any) {
      console.error("Error creating material:", error);
      res.status(400).json({ message: error.message || "Failed to create material" });
    }
  });

  app.patch("/api/materials/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const material = await storage.updateMaterial(req.params.id, req.body);
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      res.json(material);
    } catch (error) {
      console.error("Error updating material:", error);
      res.status(500).json({ message: "Failed to update material" });
    }
  });

  app.delete("/api/materials/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const success = await storage.deleteMaterial(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Material not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting material:", error);
      res.status(500).json({ message: "Failed to delete material" });
    }
  });

  // Units Routes (Admin, Owner only)
  app.get("/api/units", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const units = await storage.getAllUnits();
      res.json(units);
    } catch (error) {
      console.error("Error fetching units:", error);
      res.status(500).json({ message: "Failed to fetch units" });
    }
  });

  app.post("/api/units", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const data = insertUnitSchema.parse(req.body);
      const unit = await storage.createUnit(data);
      res.status(201).json(unit);
    } catch (error: any) {
      console.error("Error creating unit:", error);
      res.status(400).json({ message: error.message || "Failed to create unit" });
    }
  });

  app.patch("/api/units/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const unit = await storage.updateUnit(req.params.id, req.body);
      if (!unit) {
        return res.status(404).json({ message: "Unit not found" });
      }
      res.json(unit);
    } catch (error) {
      console.error("Error updating unit:", error);
      res.status(500).json({ message: "Failed to update unit" });
    }
  });

  app.delete("/api/units/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const success = await storage.deleteUnit(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Unit not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting unit:", error);
      res.status(500).json({ message: "Failed to delete unit" });
    }
  });

  // Products Routes (Admin, Owner, Produksi, Kasir can view; Admin, Owner can modify)
  app.get("/api/products", isAuthenticated, requireRole("admin", "owner", "produksi", "kasir"), async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", isAuthenticated, requireRole("admin", "owner", "produksi", "kasir"), async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const data = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(data);
      res.status(201).json(product);
    } catch (error: any) {
      console.error("Error creating product:", error);
      res.status(400).json({ message: error.message || "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const product = await storage.updateProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const success = await storage.deleteProduct(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Customers Routes (Admin, Owner, Kasir can access)
  app.get("/api/customers", isAuthenticated, requireRole("admin", "owner", "kasir"), async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      res.json(customers);
    } catch (error) {
      console.error("Error fetching customers:", error);
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", isAuthenticated, requireRole("admin", "owner", "kasir"), async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      console.error("Error fetching customer:", error);
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", isAuthenticated, requireRole("admin", "owner", "kasir"), async (req, res) => {
    try {
      const data = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(data);
      res.status(201).json(customer);
    } catch (error: any) {
      console.error("Error creating customer:", error);
      res.status(400).json({ message: error.message || "Failed to create customer" });
    }
  });

  app.patch("/api/customers/:id", isAuthenticated, requireRole("admin", "owner", "kasir"), async (req, res) => {
    try {
      const customer = await storage.updateCustomer(req.params.id, req.body);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      console.error("Error updating customer:", error);
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const success = await storage.deleteCustomer(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting customer:", error);
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Orders Routes (All roles except Keuangan can view; Admin, Owner, Kasir can create)
  app.get("/api/orders", isAuthenticated, requireRole("admin", "owner", "kasir", "produksi"), async (req, res) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", isAuthenticated, requireRole("admin", "owner", "kasir", "produksi"), async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      const items = await storage.getOrderItems(req.params.id);
      res.json({ ...order, items });
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.post("/api/orders", isAuthenticated, requireRole("admin", "owner", "kasir"), async (req: any, res) => {
    try {
      const { items, ...orderData } = req.body;
      const userId = req.user.claims.sub;
      
      // Generate invoice number
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, "0");
      const random = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
      const invoiceNumber = `INV-${year}${month}-${random}`;
      
      const orderDataWithUser = {
        ...orderData,
        invoiceNumber,
        createdBy: userId,
      };
      
      const validatedOrder = insertOrderSchema.parse(orderDataWithUser);
      const validatedItems = items.map((item: any) => insertOrderItemSchema.parse(item));
      
      const order = await storage.createOrder(validatedOrder, validatedItems);
      res.status(201).json(order);
    } catch (error: any) {
      console.error("Error creating order:", error);
      res.status(400).json({ message: error.message || "Failed to create order" });
    }
  });

  app.patch("/api/orders/:id/status", isAuthenticated, requireRole("admin", "owner", "produksi"), async (req, res) => {
    try {
      const { status } = req.body;
      const order = await storage.updateOrderStatus(req.params.id, status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Error updating order status:", error);
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  // Payments Routes (Admin, Owner, Keuangan, Kasir can access)
  app.get("/api/orders/:orderId/payments", isAuthenticated, requireRole("admin", "owner", "keuangan", "kasir"), async (req, res) => {
    try {
      const payments = await storage.getOrderPayments(req.params.orderId);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.post("/api/payments", isAuthenticated, requireRole("admin", "owner", "keuangan", "kasir"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertPaymentSchema.parse({
        ...req.body,
        createdBy: userId,
      });
      const payment = await storage.createPayment(data);
      res.status(201).json(payment);
    } catch (error: any) {
      console.error("Error creating payment:", error);
      res.status(400).json({ message: error.message || "Failed to create payment" });
    }
  });

  // Expenses Routes (Admin, Owner, Keuangan only)
  app.get("/api/expenses", isAuthenticated, requireRole("admin", "owner", "keuangan"), async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      let expenses;
      
      if (startDate && endDate) {
        expenses = await storage.getExpensesByDateRange(
          new Date(startDate as string),
          new Date(endDate as string)
        );
      } else {
        expenses = await storage.getAllExpenses();
      }
      
      res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.post("/api/expenses", isAuthenticated, requireRole("admin", "owner", "keuangan"), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertExpenseSchema.parse({
        ...req.body,
        createdBy: userId,
      });
      const expense = await storage.createExpense(data);
      res.status(201).json(expense);
    } catch (error: any) {
      console.error("Error creating expense:", error);
      res.status(400).json({ message: error.message || "Failed to create expense" });
    }
  });

  app.patch("/api/expenses/:id", isAuthenticated, requireRole("admin", "owner", "keuangan"), async (req, res) => {
    try {
      const expense = await storage.updateExpense(req.params.id, req.body);
      if (!expense) {
        return res.status(404).json({ message: "Expense not found" });
      }
      res.json(expense);
    } catch (error) {
      console.error("Error updating expense:", error);
      res.status(500).json({ message: "Failed to update expense" });
    }
  });

  app.delete("/api/expenses/:id", isAuthenticated, requireRole("admin", "owner", "keuangan"), async (req, res) => {
    try {
      const success = await storage.deleteExpense(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Expense not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting expense:", error);
      res.status(500).json({ message: "Failed to delete expense" });
    }
  });

  // Dashboard Stats Routes (Admin, Owner, Keuangan, Kasir can access)
  app.get("/api/stats/revenue", isAuthenticated, requireRole("admin", "owner", "keuangan", "kasir"), async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const stats = await storage.getRevenueStats(
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      res.json(stats);
    } catch (error) {
      console.error("Error fetching revenue stats:", error);
      res.status(500).json({ message: "Failed to fetch revenue stats" });
    }
  });

  app.get("/api/stats/products", isAuthenticated, requireRole("admin", "owner", "keuangan"), async (req, res) => {
    try {
      const stats = await storage.getProductRevenueStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching product stats:", error);
      res.status(500).json({ message: "Failed to fetch product stats" });
    }
  });

  // App Settings Routes (Admin, Owner only)
  app.get("/api/settings", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const settings = await storage.getAppSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", isAuthenticated, requireRole("admin", "owner"), async (req, res) => {
    try {
      const data = insertAppSettingSchema.parse(req.body);
      const settings = await storage.upsertAppSettings(data);
      res.json(settings);
    } catch (error: any) {
      console.error("Error updating settings:", error);
      res.status(400).json({ message: error.message || "Failed to update settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
