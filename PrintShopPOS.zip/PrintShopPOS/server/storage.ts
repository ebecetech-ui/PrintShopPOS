import {
  users,
  products,
  productTypes,
  materials,
  units,
  customers,
  orders,
  orderItems,
  payments,
  expenses,
  appSettings,
  type User,
  type UpsertUser,
  type Product,
  type InsertProduct,
  type ProductType,
  type InsertProductType,
  type Material,
  type InsertMaterial,
  type Unit,
  type InsertUnit,
  type Customer,
  type InsertCustomer,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type Payment,
  type InsertPayment,
  type Expense,
  type InsertExpense,
  type AppSetting,
  type InsertAppSetting,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRole(userId: string, role: User["role"]): Promise<User | undefined>;

  // Product Types
  getAllProductTypes(): Promise<ProductType[]>;
  createProductType(data: InsertProductType): Promise<ProductType>;
  updateProductType(id: string, data: Partial<InsertProductType>): Promise<ProductType | undefined>;
  deleteProductType(id: string): Promise<boolean>;

  // Materials
  getAllMaterials(): Promise<Material[]>;
  createMaterial(data: InsertMaterial): Promise<Material>;
  updateMaterial(id: string, data: Partial<InsertMaterial>): Promise<Material | undefined>;
  deleteMaterial(id: string): Promise<boolean>;

  // Units
  getAllUnits(): Promise<Unit[]>;
  createUnit(data: InsertUnit): Promise<Unit>;
  updateUnit(id: string, data: Partial<InsertUnit>): Promise<Unit | undefined>;
  deleteUnit(id: string): Promise<boolean>;

  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(data: InsertProduct): Promise<Product>;
  updateProduct(id: string, data: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Customers
  getAllCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  createCustomer(data: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, data: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: string): Promise<boolean>;

  // Orders
  getAllOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(id: string, status: Order["status"]): Promise<Order | undefined>;
  updatePaymentStatus(id: string, paymentStatus: Order["paymentStatus"]): Promise<Order | undefined>;

  // Payments
  getOrderPayments(orderId: string): Promise<Payment[]>;
  createPayment(data: InsertPayment): Promise<Payment>;

  // Expenses
  getAllExpenses(): Promise<Expense[]>;
  getExpensesByDateRange(startDate: Date, endDate: Date): Promise<Expense[]>;
  createExpense(data: InsertExpense): Promise<Expense>;
  updateExpense(id: string, data: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: string): Promise<boolean>;

  // App Settings
  getAppSettings(): Promise<AppSetting | undefined>;
  upsertAppSettings(data: InsertAppSetting): Promise<AppSetting>;

  // Dashboard Stats
  getRevenueStats(startDate?: Date, endDate?: Date): Promise<any>;
  getProductRevenueStats(): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRole(userId: string, role: User["role"]): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Product Types
  async getAllProductTypes(): Promise<ProductType[]> {
    return await db.select().from(productTypes).orderBy(productTypes.name);
  }

  async createProductType(data: InsertProductType): Promise<ProductType> {
    const [type] = await db.insert(productTypes).values(data).returning();
    return type;
  }

  async updateProductType(id: string, data: Partial<InsertProductType>): Promise<ProductType | undefined> {
    const [type] = await db.update(productTypes).set(data).where(eq(productTypes.id, id)).returning();
    return type;
  }

  async deleteProductType(id: string): Promise<boolean> {
    const result = await db.delete(productTypes).where(eq(productTypes.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Materials
  async getAllMaterials(): Promise<Material[]> {
    return await db.select().from(materials).orderBy(materials.name);
  }

  async createMaterial(data: InsertMaterial): Promise<Material> {
    const [material] = await db.insert(materials).values(data).returning();
    return material;
  }

  async updateMaterial(id: string, data: Partial<InsertMaterial>): Promise<Material | undefined> {
    const [material] = await db.update(materials).set(data).where(eq(materials.id, id)).returning();
    return material;
  }

  async deleteMaterial(id: string): Promise<boolean> {
    const result = await db.delete(materials).where(eq(materials.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Units
  async getAllUnits(): Promise<Unit[]> {
    return await db.select().from(units).orderBy(units.name);
  }

  async createUnit(data: InsertUnit): Promise<Unit> {
    const [unit] = await db.insert(units).values(data).returning();
    return unit;
  }

  async updateUnit(id: string, data: Partial<InsertUnit>): Promise<Unit | undefined> {
    const [unit] = await db.update(units).set(data).where(eq(units.id, id)).returning();
    return unit;
  }

  async deleteUnit(id: string): Promise<boolean> {
    const result = await db.delete(units).where(eq(units.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(products.name);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(data: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(data).returning();
    return product;
  }

  async updateProduct(id: string, data: Partial<InsertProduct>): Promise<Product | undefined> {
    const [product] = await db.update(products).set(data).where(eq(products.id, id)).returning();
    return product;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Customers
  async getAllCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async createCustomer(data: InsertCustomer): Promise<Customer> {
    const [customer] = await db.insert(customers).values(data).returning();
    return customer;
  }

  async updateCustomer(id: string, data: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const [customer] = await db.update(customers).set(data).where(eq(customers.id, id)).returning();
    return customer;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = await db.delete(customers).where(eq(customers.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Orders
  async getAllOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.orderDate));
  }

  async getOrder(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const [createdOrder] = await db.insert(orders).values(order).returning();
    
    if (items.length > 0) {
      const itemsWithOrderId = items.map(item => ({
        ...item,
        orderId: createdOrder.id,
      }));
      await db.insert(orderItems).values(itemsWithOrderId);
    }
    
    return createdOrder;
  }

  async updateOrderStatus(id: string, status: Order["status"]): Promise<Order | undefined> {
    const [order] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
    return order;
  }

  async updatePaymentStatus(id: string, paymentStatus: Order["paymentStatus"]): Promise<Order | undefined> {
    const [order] = await db.update(orders).set({ paymentStatus }).where(eq(orders.id, id)).returning();
    return order;
  }

  // Payments
  async getOrderPayments(orderId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.orderId, orderId)).orderBy(desc(payments.paymentDate));
  }

  async createPayment(data: InsertPayment): Promise<Payment> {
    const [payment] = await db.insert(payments).values(data).returning();
    
    // Update order payment status based on total payments
    const allPayments = await this.getOrderPayments(data.orderId);
    const totalPaid = allPayments.reduce((sum, p) => sum + parseFloat(p.amount), 0);
    const order = await this.getOrder(data.orderId);
    
    if (order) {
      const orderTotal = parseFloat(order.totalAmount);
      if (totalPaid >= orderTotal) {
        await this.updatePaymentStatus(data.orderId, "paid");
      } else if (totalPaid > 0) {
        await this.updatePaymentStatus(data.orderId, "partial");
      }
    }
    
    return payment;
  }

  // Expenses
  async getAllExpenses(): Promise<Expense[]> {
    return await db.select().from(expenses).orderBy(desc(expenses.expenseDate));
  }

  async getExpensesByDateRange(startDate: Date, endDate: Date): Promise<Expense[]> {
    return await db
      .select()
      .from(expenses)
      .where(and(gte(expenses.expenseDate, startDate), lte(expenses.expenseDate, endDate)))
      .orderBy(desc(expenses.expenseDate));
  }

  async createExpense(data: InsertExpense): Promise<Expense> {
    const [expense] = await db.insert(expenses).values(data).returning();
    return expense;
  }

  async updateExpense(id: string, data: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [expense] = await db.update(expenses).set(data).where(eq(expenses.id, id)).returning();
    return expense;
  }

  async deleteExpense(id: string): Promise<boolean> {
    const result = await db.delete(expenses).where(eq(expenses.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // App Settings
  async getAppSettings(): Promise<AppSetting | undefined> {
    const [settings] = await db.select().from(appSettings).limit(1);
    return settings;
  }

  async upsertAppSettings(data: InsertAppSetting): Promise<AppSetting> {
    const existing = await this.getAppSettings();
    
    if (existing) {
      const [updated] = await db
        .update(appSettings)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(appSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(appSettings).values(data).returning();
      return created;
    }
  }

  // Dashboard Stats
  async getRevenueStats(startDate?: Date, endDate?: Date): Promise<any> {
    let query = db.select({
      totalRevenue: sql<number>`COALESCE(SUM(CAST(${orders.totalAmount} AS DECIMAL)), 0)`,
      totalOrders: sql<number>`COUNT(*)`,
    }).from(orders);

    if (startDate && endDate) {
      query = query.where(and(gte(orders.orderDate, startDate), lte(orders.orderDate, endDate))) as any;
    }

    const [stats] = await query;
    return stats;
  }

  async getProductRevenueStats(): Promise<any[]> {
    const stats = await db
      .select({
        productId: products.id,
        productName: products.name,
        totalQuantity: sql<number>`COALESCE(SUM(CAST(${orderItems.quantity} AS DECIMAL)), 0)`,
        totalRevenue: sql<number>`COALESCE(SUM(CAST(${orderItems.subtotal} AS DECIMAL)), 0)`,
      })
      .from(orderItems)
      .leftJoin(products, eq(orderItems.productId, products.id))
      .groupBy(products.id, products.name)
      .orderBy(desc(sql`COALESCE(SUM(CAST(${orderItems.subtotal} AS DECIMAL)), 0)`));

    return stats;
  }
}

export const storage = new DatabaseStorage();
