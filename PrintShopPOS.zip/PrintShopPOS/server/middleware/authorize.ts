import type { RequestHandler } from "express";
import { storage } from "../storage";
import type { User } from "@shared/schema";

type Role = User["role"];

export function requireRole(...allowedRoles: Role[]): RequestHandler {
  return async (req: any, res, next) => {
    if (!req.user || !req.user.claims || !req.user.claims.sub) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({ 
          message: "Forbidden - Insufficient permissions",
          requiredRoles: allowedRoles,
          userRole: user.role,
        });
      }

      // Attach user to request for later use
      (req as any).currentUser = user;
      next();
    } catch (error) {
      console.error("Error checking user role:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  };
}

// Helper to get current user from request
export function getCurrentUser(req: any): User | undefined {
  return (req as any).currentUser;
}
