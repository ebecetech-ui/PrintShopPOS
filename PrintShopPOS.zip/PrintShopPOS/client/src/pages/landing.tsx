import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Receipt, ShoppingCart, Users, TrendingUp, FileText, Wallet } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <Receipt className="h-10 w-10" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-foreground mb-4">
            POS Percetakan
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Sistem manajemen order, invoice otomatis, dan pembukuan lengkap untuk bisnis percetakan Anda
          </p>
          <Button size="lg" asChild data-testid="button-login">
            <a href="/api/login">
              Masuk ke Dashboard
            </a>
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-16">
          <Card>
            <CardHeader>
              <ShoppingCart className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Manajemen Order</CardTitle>
              <CardDescription>
                Buat order dan invoice otomatis dengan mudah
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <FileText className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Pembukuan Lengkap</CardTitle>
              <CardDescription>
                Lacak piutang, uang masuk, dan pengeluaran secara real-time
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <TrendingUp className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Laporan Omset</CardTitle>
              <CardDescription>
                Visualisasi omset global dan per produk dengan grafik
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Users className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Data Konsumen</CardTitle>
              <CardDescription>
                Kelola data konsumen dan riwayat transaksi
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Wallet className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Multi-Payment</CardTitle>
              <CardDescription>
                Dukungan Cash, Transfer Bank, dan E-wallet
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Receipt className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Role-Based Access</CardTitle>
              <CardDescription>
                5 role berbeda: Admin, Owner, Produksi, Keuangan, Kasir
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Powered by Replit Auth • Secure & Reliable
          </p>
        </div>
      </div>
    </div>
  );
}
