import { OrderForm } from "@/components/order-form";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function NewOrder() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" data-testid="button-back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-foreground">Buat Order Baru</h1>
          <p className="text-muted-foreground mt-1">Tambahkan order baru ke sistem</p>
        </div>
      </div>

      <OrderForm />
    </div>
  );
}
