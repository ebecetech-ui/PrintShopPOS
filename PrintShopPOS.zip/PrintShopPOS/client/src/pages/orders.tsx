import { OrderList } from "@/components/order-list";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function Orders() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Data Order</h1>
          <p className="text-muted-foreground mt-1">Kelola semua order percetakan</p>
        </div>
        <Button data-testid="button-new-order">
          <Plus className="h-4 w-4 mr-2" />
          Order Baru
        </Button>
      </div>

      <OrderList />
    </div>
  );
}
