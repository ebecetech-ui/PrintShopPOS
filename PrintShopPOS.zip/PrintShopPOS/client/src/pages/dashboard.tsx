import { DashboardMetricCard } from "@/components/dashboard-metric-card";
import { FinancialChart } from "@/components/financial-chart";
import { OrderList } from "@/components/order-list";
import { DollarSign, ShoppingCart, Users, TrendingUp } from "lucide-react";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Ringkasan data percetakan Anda</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <DashboardMetricCard
          title="Total Omset Bulan Ini"
          value="Rp 42.500.000"
          icon={DollarSign}
          trend={{ value: 12.5, isPositive: true }}
        />
        <DashboardMetricCard
          title="Total Order"
          value="156"
          icon={ShoppingCart}
          trend={{ value: 8.2, isPositive: true }}
        />
        <DashboardMetricCard
          title="Konsumen Aktif"
          value="48"
          icon={Users}
          trend={{ value: 3.1, isPositive: false }}
        />
        <DashboardMetricCard
          title="Piutang"
          value="Rp 15.200.000"
          icon={TrendingUp}
          subtitle="12 transaksi belum lunas"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-1">
        <FinancialChart />
      </div>

      <OrderList />
    </div>
  );
}
