import { Home, ShoppingCart, Package, Users, Wallet, Settings, Database, RefreshCw, FileText, DollarSign, TrendingUp, Receipt, CreditCard, LogOut } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface AppSidebarProps {
  userRole?: "admin" | "owner" | "produksi" | "keuangan" | "kasir";
}

export function AppSidebar({ userRole = "admin" }: AppSidebarProps) {
  const menuItems = [
    {
      title: "Dashboard",
      url: "/",
      icon: Home,
      roles: ["admin", "owner", "keuangan", "kasir"],
    },
    {
      title: "Data Order",
      icon: ShoppingCart,
      roles: ["admin", "owner", "kasir", "produksi"],
      subItems: [
        { title: "Semua Order", url: "/orders" },
        { title: "Buat Order Baru", url: "/orders/new" },
      ],
    },
    {
      title: "Master Data",
      icon: Package,
      roles: ["admin", "owner"],
      subItems: [
        { title: "Produk", url: "/master/products" },
        { title: "Jenis", url: "/master/types" },
        { title: "Bahan", url: "/master/materials" },
        { title: "Satuan Produk", url: "/master/units" },
      ],
    },
    {
      title: "Pembukuan",
      icon: FileText,
      roles: ["admin", "owner", "keuangan"],
      subItems: [
        { title: "Piutang", url: "/accounting/receivables" },
        { title: "Omset Global", url: "/accounting/revenue" },
        { title: "Omset Produk", url: "/accounting/product-revenue" },
        { title: "Uang Masuk", url: "/accounting/income" },
        { title: "Pengeluaran", url: "/accounting/expenses" },
        { title: "Data Rekap", url: "/accounting/summary" },
      ],
    },
    {
      title: "Konsumen",
      url: "/customers",
      icon: Users,
      roles: ["admin", "owner", "kasir"],
    },
    {
      title: "Keuangan",
      url: "/finance",
      icon: Wallet,
      roles: ["admin", "owner", "keuangan"],
    },
    {
      title: "Pengaturan",
      icon: Settings,
      roles: ["admin", "owner"],
      subItems: [
        { title: "Pengguna", url: "/settings/users", adminOnly: true },
        { title: "Aplikasi", url: "/settings/app" },
        { title: "Pembayaran", url: "/settings/payment" },
        { title: "Menu Admin", url: "/settings/admin", adminOnly: true },
      ],
    },
    {
      title: "Backup Database",
      url: "/backup",
      icon: Database,
      roles: ["admin"],
    },
    {
      title: "Check Update",
      url: "/updates",
      icon: RefreshCw,
      roles: ["admin", "owner"],
    },
  ];

  const filteredMenuItems = menuItems.filter(item => 
    item.roles.includes(userRole)
  );

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Receipt className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-sidebar-foreground">POS Percetakan</h2>
            <p className="text-xs text-muted-foreground">Sistem Manajemen</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredMenuItems.map((item) => (
                item.subItems ? (
                  <Collapsible key={item.title} asChild defaultOpen={false}>
                    <SidebarMenuItem>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}>
                          {item.icon && <item.icon className="h-4 w-4" />}
                          <span>{item.title}</span>
                          <ChevronDown className="ml-auto h-4 w-4" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.subItems
                            .filter(subItem => !subItem.adminOnly || userRole === 'admin')
                            .map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton asChild>
                                <a href={subItem.url} data-testid={`nav-${subItem.title.toLowerCase().replace(/\s+/g, '-')}`}>
                                  <span>{subItem.title}</span>
                                </a>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </SidebarMenuItem>
                  </Collapsible>
                ) : (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <a href={item.url} data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}>
                        {item.icon && <item.icon className="h-4 w-4" />}
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border p-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <a href="/api/logout" data-testid="button-logout">
                <LogOut className="h-4 w-4" />
                <span>Keluar</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
