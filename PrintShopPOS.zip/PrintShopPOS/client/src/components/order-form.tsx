import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface OrderItem {
  id: string;
  product: string;
  quantity: number;
  unit: string;
  price: number;
}

export function OrderForm() {
  const [customer, setCustomer] = useState("");
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [currentProduct, setCurrentProduct] = useState("");
  const [currentQuantity, setCurrentQuantity] = useState("");
  const [currentUnit, setCurrentUnit] = useState("");
  const [currentPrice, setCurrentPrice] = useState("");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");

  const addItem = () => {
    if (currentProduct && currentQuantity && currentUnit && currentPrice) {
      const newItem: OrderItem = {
        id: Date.now().toString(),
        product: currentProduct,
        quantity: parseFloat(currentQuantity),
        unit: currentUnit,
        price: parseFloat(currentPrice),
      };
      setOrderItems([...orderItems, newItem]);
      setCurrentProduct("");
      setCurrentQuantity("");
      setCurrentUnit("");
      setCurrentPrice("");
      console.log("Item ditambahkan:", newItem);
    }
  };

  const removeItem = (id: string) => {
    setOrderItems(orderItems.filter(item => item.id !== id));
    console.log("Item dihapus:", id);
  };

  const totalAmount = orderItems.reduce((sum, item) => sum + (item.quantity * item.price), 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Order submitted:", { customer, orderItems, notes, paymentMethod, totalAmount });
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Buat Order Baru</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customer">Nama Konsumen</Label>
              <Select value={customer} onValueChange={setCustomer}>
                <SelectTrigger id="customer" data-testid="select-customer">
                  <SelectValue placeholder="Pilih konsumen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer1">PT Maju Jaya</SelectItem>
                  <SelectItem value="customer2">CV Berkah Abadi</SelectItem>
                  <SelectItem value="customer3">Toko Sentosa</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment">Metode Pembayaran</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger id="payment" data-testid="select-payment">
                  <SelectValue placeholder="Pilih metode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="transfer">Transfer Bank</SelectItem>
                  <SelectItem value="ewallet">E-wallet</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <Label>Tambah Produk</Label>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <Input
                placeholder="Nama produk"
                value={currentProduct}
                onChange={(e) => setCurrentProduct(e.target.value)}
                data-testid="input-product-name"
              />
              <Input
                type="number"
                placeholder="Jumlah"
                value={currentQuantity}
                onChange={(e) => setCurrentQuantity(e.target.value)}
                data-testid="input-quantity"
              />
              <Select value={currentUnit} onValueChange={setCurrentUnit}>
                <SelectTrigger data-testid="select-unit">
                  <SelectValue placeholder="Satuan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pcs">Pcs</SelectItem>
                  <SelectItem value="rim">Rim</SelectItem>
                  <SelectItem value="box">Box</SelectItem>
                  <SelectItem value="meter">Meter</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Harga"
                value={currentPrice}
                onChange={(e) => setCurrentPrice(e.target.value)}
                data-testid="input-price"
              />
              <Button type="button" onClick={addItem} data-testid="button-add-item">
                <Plus className="h-4 w-4 mr-2" />
                Tambah
              </Button>
            </div>
          </div>

          {orderItems.length > 0 && (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Produk</TableHead>
                    <TableHead>Jumlah</TableHead>
                    <TableHead>Satuan</TableHead>
                    <TableHead>Harga</TableHead>
                    <TableHead className="text-right">Subtotal</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orderItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.product}</TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell>{item.unit}</TableCell>
                      <TableCell>Rp {item.price.toLocaleString('id-ID')}</TableCell>
                      <TableCell className="text-right">
                        Rp {(item.quantity * item.price).toLocaleString('id-ID')}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          data-testid={`button-remove-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Catatan</Label>
            <Textarea
              id="notes"
              placeholder="Tambahkan catatan untuk order ini..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="textarea-notes"
            />
          </div>

          {orderItems.length > 0 && (
            <div className="flex justify-end pt-4 border-t">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-3xl font-bold text-foreground" data-testid="text-total">
                  Rp {totalAmount.toLocaleString('id-ID')}
                </p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button variant="outline" type="button" data-testid="button-cancel">
            Batal
          </Button>
          <Button type="submit" disabled={orderItems.length === 0} data-testid="button-submit">
            Buat Order & Invoice
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
