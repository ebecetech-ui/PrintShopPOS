import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Plus, Eye, Edit, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Customer {
  id: string;
  name: string;
  contact: string;
  email: string;
  totalOrders: number;
  totalSpent: number;
  status: "active" | "inactive";
}

export function CustomerTable() {
  const [searchTerm, setSearchTerm] = useState("");

  const customers: Customer[] = [
    {
      id: "1",
      name: "PT Maju Jaya",
      contact: "081234567890",
      email: "info@majujaya.com",
      totalOrders: 15,
      totalSpent: 45000000,
      status: "active",
    },
    {
      id: "2",
      name: "CV Berkah Abadi",
      contact: "081234567891",
      email: "admin@berkah.com",
      totalOrders: 8,
      totalSpent: 22000000,
      status: "active",
    },
    {
      id: "3",
      name: "Toko Sentosa",
      contact: "081234567892",
      email: "sentosa@email.com",
      totalOrders: 3,
      totalSpent: 5500000,
      status: "inactive",
    },
  ];

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <CardTitle>Data Konsumen</CardTitle>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari konsumen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 w-full sm:w-[250px]"
                data-testid="input-search-customer"
              />
            </div>
            <Button data-testid="button-add-customer">
              <Plus className="h-4 w-4 mr-2" />
              Tambah Konsumen
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nama</TableHead>
                <TableHead>Kontak</TableHead>
                <TableHead>Email</TableHead>
                <TableHead className="text-center">Total Order</TableHead>
                <TableHead className="text-right">Total Belanja</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow key={customer.id} data-testid={`row-customer-${customer.id}`}>
                  <TableCell className="font-medium">{customer.name}</TableCell>
                  <TableCell>{customer.contact}</TableCell>
                  <TableCell>{customer.email}</TableCell>
                  <TableCell className="text-center">{customer.totalOrders}</TableCell>
                  <TableCell className="text-right">
                    Rp {customer.totalSpent.toLocaleString('id-ID')}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant={customer.status === "active" ? "default" : "secondary"}>
                      {customer.status === "active" ? "Aktif" : "Tidak Aktif"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" data-testid={`button-view-${customer.id}`}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid={`button-edit-${customer.id}`}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" data-testid={`button-delete-${customer.id}`}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
