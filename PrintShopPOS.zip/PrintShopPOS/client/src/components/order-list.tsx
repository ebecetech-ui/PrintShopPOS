import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Eye, Printer } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Order {
  id: string;
  invoiceNumber: string;
  customer: string;
  date: string;
  total: number;
  status: "pending" | "processing" | "completed" | "cancelled";
  paymentStatus: "unpaid" | "partial" | "paid";
}

export function OrderList() {
  const [searchTerm, setSearchTerm] = useState("");

  const orders: Order[] = [
    {
      id: "1",
      invoiceNumber: "INV-2024-001",
      customer: "PT Maju Jaya",
      date: "2024-01-15",
      total: 5500000,
      status: "completed",
      paymentStatus: "paid",
    },
    {
      id: "2",
      invoiceNumber: "INV-2024-002",
      customer: "CV Berkah Abadi",
      date: "2024-01-16",
      total: 3200000,
      status: "processing",
      paymentStatus: "partial",
    },
    {
      id: "3",
      invoiceNumber: "INV-2024-003",
      customer: "Toko Sentosa",
      date: "2024-01-17",
      total: 1800000,
      status: "pending",
      paymentStatus: "unpaid",
    },
  ];

  const filteredOrders = orders.filter(order =>
    order.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.customer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: Order["status"]) => {
    const variants: Record<Order["status"], { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
      pending: { label: "Menunggu", variant: "secondary" },
      processing: { label: "Proses", variant: "default" },
      completed: { label: "Selesai", variant: "outline" },
      cancelled: { label: "Batal", variant: "destructive" },
    };
    return variants[status];
  };

  const getPaymentBadge = (status: Order["paymentStatus"]) => {
    const variants: Record<Order["paymentStatus"], { label: string; color: string }> = {
      unpaid: { label: "Belum Bayar", color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200" },
      partial: { label: "Bayar Sebagian", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200" },
      paid: { label: "Lunas", color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200" },
    };
    return variants[status];
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <CardTitle>Daftar Order</CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cari order atau konsumen..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 w-full sm:w-[300px]"
              data-testid="input-search-order"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>No. Invoice</TableHead>
                <TableHead>Konsumen</TableHead>
                <TableHead>Tanggal</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-center">Status Order</TableHead>
                <TableHead className="text-center">Status Bayar</TableHead>
                <TableHead className="text-right">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => {
                const statusBadge = getStatusBadge(order.status);
                const paymentBadge = getPaymentBadge(order.paymentStatus);
                
                return (
                  <TableRow key={order.id} data-testid={`row-order-${order.id}`}>
                    <TableCell className="font-medium">{order.invoiceNumber}</TableCell>
                    <TableCell>{order.customer}</TableCell>
                    <TableCell>{new Date(order.date).toLocaleDateString('id-ID')}</TableCell>
                    <TableCell className="text-right font-medium">
                      Rp {order.total.toLocaleString('id-ID')}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={statusBadge.variant}>{statusBadge.label}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className={paymentBadge.color}>{paymentBadge.label}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" data-testid={`button-view-${order.id}`}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" data-testid={`button-print-${order.id}`}>
                          <Printer className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
