import { ProductTable } from '../product-table';

export default function ProductTableExample() {
  return (
    <div className="p-6">
      <ProductTable />
    </div>
  );
}
