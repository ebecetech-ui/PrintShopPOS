import { DashboardMetricCard } from '../dashboard-metric-card';
import { DollarSign } from 'lucide-react';

export default function DashboardMetricCardExample() {
  return (
    <div className="p-6">
      <DashboardMetricCard
        title="Total Omset Bulan Ini"
        value="Rp 42.500.000"
        icon={DollarSign}
        trend={{ value: 12.5, isPositive: true }}
      />
    </div>
  );
}
