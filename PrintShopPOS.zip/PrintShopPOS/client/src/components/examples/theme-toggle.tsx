import { ThemeToggle } from '../theme-toggle';

export default function ThemeToggleExample() {
  return (
    <div className="p-6 flex items-center gap-4">
      <span className="text-sm text-muted-foreground">Theme Toggle:</span>
      <ThemeToggle />
    </div>
  );
}
