import { CustomerTable } from '../customer-table';

export default function CustomerTableExample() {
  return (
    <div className="p-6">
      <CustomerTable />
    </div>
  );
}
