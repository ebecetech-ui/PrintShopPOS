import { OrderList } from '../order-list';

export default function OrderListExample() {
  return (
    <div className="p-6">
      <OrderList />
    </div>
  );
}
