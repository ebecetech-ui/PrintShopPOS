import { FinancialChart } from '../financial-chart';

export default function FinancialChartExample() {
  return (
    <div className="p-6">
      <FinancialChart />
    </div>
  );
}
