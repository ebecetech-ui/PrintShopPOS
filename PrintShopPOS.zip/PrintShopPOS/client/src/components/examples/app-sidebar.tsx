import { AppSidebar } from '../app-sidebar';

export default function AppSidebarExample() {
  return <AppSidebar userRole="admin" />;
}
