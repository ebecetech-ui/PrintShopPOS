import { OrderForm } from '../order-form';

export default function OrderFormExample() {
  return (
    <div className="p-6">
      <OrderForm />
    </div>
  );
}
